#include "led.h"
#include "delay.h"
#include "sys.h"
#include "usart.h"
#include "key.h"
#include "usart2.h"	
#include "nfc.h"
#include "timer.h"
#include "beep.h"

#define ADMIN_NUM 13 
//11

const u8 AdminID[ADMIN_NUM][4]={
	{0xA6,0x02,0x3C,0xDD},//boss
	{0xA3,0xD5,0xA1,0xD2},//	����Ա1
	{0x14,0xEF,0xAD,0xD4},//	����Ա2
	{0xE6,0xC7,0xAF,0xFC},//	�����
	{0xC3,0xC5,0xF4,0x68},//	����
	{0x86,0x37,0xE5,0xC1},//	������
	{0x06,0xAC,0xD0,0xDD},//	�װ���
	{0xD6,0xC7,0xAF,0xFC},//	ëС��
	{0xF6,0xC8,0xAF,0xFC},//	�䳬
	{0xA6,0x95,0x35,0xDD},//	������
	{0xC6,0x82,0x3C,0xDD},//	ۨ����	
	{0xF0,0x1A,0xDF,0x9C},//	wb
	{0x06,0xE2,0xD3,0xDD}//	lbj
	
};

u8 UidArray[10];
u8 LastUid[10]={0,0,0,0,0};

void AdminOpenDoor(u8 *uid);
void CleanBuf(u8 buf[],u16 len);
u8 IfRepeat(u16 set_second);


 int main(void)
 { 
  NVIC_Configuration();	 
	delay_init();	    	 //��ʱ������ʼ��	  
	uart_init(115200);	 	//���ڳ�ʼ��Ϊ9600			 
	LED_Init();         	//LED��ʼ��	 
	KEY_Init();				//������ʼ��	  													    
 	USART2_Init(115200);	//��ʼ������2 //
	TIM3_Int_Init(7200,10000);//����1S��ʱ���ʱ
	 BEEP_Init();
//	printf("Hello \r\n");
	 KEY_Init();
 
 	nfc_WakeUp();	

BEEP=1;
delay_ms(50);
BEEP=0;
delay_ms(50);
BEEP=1;
delay_ms(50);
BEEP=0;
delay_ms(50);
BEEP=1;
delay_ms(50);
BEEP=0;
delay_ms(50);


	while(1)
	{
		if(KEY1_PRES==KEY_Scan(0))
		{
			printf("{\"syn\":1001,\"id\":4,\"packetType\":1003,\"cmd\":1}\n");//ǿ�ƿ���
BEEP=1;
delay_ms(50);
BEEP=0;
delay_ms(50);
BEEP=1;
delay_ms(50);
BEEP=0;
delay_ms(50);
BEEP=1;
delay_ms(50);
BEEP=0;
delay_ms(50);

		}
//		delay_ms(100);
		GetUID(UidArray);
		if(!IfRepeat(5))
		{
			printf("{\"syn\":1000,\"id\":4,\"packetType\":1003,\"userID\":\"%X%X%X%X\"}\n",UidArray[1],UidArray[2],UidArray[3],UidArray[4]);
			BEEP=1;
			delay_ms(100);
			BEEP=0;
			AdminOpenDoor(UidArray);
		}
		CleanBuf(UidArray,8);
		
	}
}

u8 IfRepeat(u16 set_second)
{
//	printf("%d\r\n",SecondCount);
	if(UidArray[1]||UidArray[2]||UidArray[3]||UidArray[4])
	{
		
		if((LastUid[1]==UidArray[1])&&(LastUid[2]==UidArray[2])&&(LastUid[3]==UidArray[3])&&(LastUid[4]==UidArray[4]))
		{
			if(SecondCount>set_second)
			{
				SecondCount=0;
				return 0;
			}
			else 
				return 1;
		}
		else
		{
			LastUid[1]=UidArray[1];
			LastUid[2]=UidArray[2];
			LastUid[3]=UidArray[3];
			LastUid[4]=UidArray[4];
			SecondCount=0;
			return 0;
		}
	}
	else
		return 1;
		
}


void CleanBuf(u8 buf[],u16 len)
{
	u16 i;
	for(i=0;i<len;i++)
	{
			buf[i]=0;
	}
}


void AdminOpenDoor(u8 *uid)
{
	u8 i=0,j=0;
	u8 count=0;

	
	for(i=0;i<ADMIN_NUM;i++)
	{
		for(j=0;j<4;j++)
		{
			if(AdminID[i][j]==uid[j+1])
			{
				count++;
			}
		}
//		printf("%d\n",count);
		if(4==count)
		{
			printf("{\"syn\":1001,\"id\":4,\"packetType\":1003,\"cmd\":1}\n");//ǿ�ƿ���

			BEEP=1;
			delay_ms(500);
			BEEP=0;


		}
		count=0;
	}
	
}


