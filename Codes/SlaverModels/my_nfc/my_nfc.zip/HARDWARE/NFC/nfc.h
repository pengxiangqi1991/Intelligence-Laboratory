#ifndef __NFC_H__
#define __NFC_H__

#include "sys.h"  
void nfc_WakeUp(void);//����
extern u8 FlagRecFished;
void GetUID(u8 *uid);


#endif /* __NFC_H__ */





