#include "nfc.h"
#include "usart2.h"
#include "usart.h"
#include "delay.h"


u8 WakeUpMsg[24]={0x55,0x55 ,0x00 ,0x00 ,0x00 ,0x00 ,0x00 ,0x00 ,0x00 ,0x00 ,0x00 ,0x00 ,0x00 ,0x00 ,0x00 ,0x00 ,0xFF ,0x03 ,0xFD ,0xD4 ,0x14 ,0x01 ,0x17 ,0x00}	;
u8 GedUIDMsg[11]={0x00 ,0x00 ,0xFF ,0x04 ,0xFC ,0xD4 ,0x4A ,0x01 ,0x00 ,0xE1 ,0x00}	;

u8 FlagRecFished;
void CleanBuffer(u16 num);//���� ǰ ���ٸ��ֽڵ�����

void nfc_WakeUp(void)
{
	u8 i;
	u8 temp=0;
	u8 CheckCode=0; //����У����

	while(1)
	{
		FlagRecFished=0;
		Usart2PutStr(WakeUpMsg,24);
		//00 00 FF 00 FF 00 00 00 FF 02 FE D5 15 16 00
		delay_ms(100);
		if(FlagRecFished)
		{
// 			printf("FlagRecFished = 1 \r\n");

			FlagRecFished = 0;
			for(i=11;i<13;i++)
			{
					temp+=USART2_RX_BUF[i];
			}
			CheckCode=0x100-temp;
			if(CheckCode==USART2_RX_BUF[13])
			{
					CheckCode=0x100-temp;
 					CleanBuffer(40);//��� ���ڽ��ջ�����ǰ30 ���ֽ�����
					
//					printf("waked up\r\n");
					break;
			}
		}
	}
}

void ReadYulanCard(u8 *uid)
{
	u16 i;
	u16 start_index=0;
// 		printf("USART2_RX_STA:%d\r\n",USART2_RX_STA);

	for(i=0;i<USART2_RX_STA;i++)//00 00 FF    1C E4
	{
		if((0x00==USART2_RX_BUF[i])&&(0x00==USART2_RX_BUF[i+1])&&(0xFF==USART2_RX_BUF[i+2]))
		{

			if((0x1C==USART2_RX_BUF[i+3])&&(0xE4==USART2_RX_BUF[i+4]))
			{
				start_index = i;//��¼��ʼλ��
// printf("start_index=:%d\r\n\r\n",start_index);
// 							while(1){}
					uid[0]='Y';////������
					uid[1]=USART2_RX_BUF[start_index+13];
					uid[2]=USART2_RX_BUF[start_index+14];
					uid[3]=USART2_RX_BUF[start_index+15];
					uid[4]=USART2_RX_BUF[start_index+16];  
// 					printf("YulanUID:");
// 					printf("%X ",uid[0]);
// 					printf("%X ",uid[1]);
// 					printf("%X ",uid[2]);
// 					printf("%X \r\n",uid[3]);
			}
		}
	}

}
void ReadBlueWhiteCard(u8 *uid)//������׿�  RFID��
{
	u16 i;
	u16 start_index=0;
//00 00 FF 0C F4 D5 4B 01 01 00 04 08 04 14 EF AD D4 4A 00
	for(i=0;i<USART2_RX_STA;i++)//00 00 FF    1C E4
	{
		if((0x00==USART2_RX_BUF[i])&&(0x00==USART2_RX_BUF[i+1])&&(0xFF==USART2_RX_BUF[i+2]))
		{
			if((0x0C==USART2_RX_BUF[i+3])&&(0xF4==USART2_RX_BUF[i+4]))
			{
				start_index = i;//��¼��ʼλ��
// printf("start_index=:%d\r\n\r\n",start_index);
// 							while(1){}
					uid[0]='B';////������׿�  RFID��
					uid[1]=USART2_RX_BUF[start_index+13];
					uid[2]=USART2_RX_BUF[start_index+14];
					uid[3]=USART2_RX_BUF[start_index+15];
					uid[4]=USART2_RX_BUF[start_index+16];  
// 					printf("Blue_WhiteCard:");
// 					printf("%X ",uid[0]);
// 					printf("%X ",uid[1]);
// 					printf("%X ",uid[2]);
// 					printf("%X \r\n",uid[3]);
			}
		}
	}
	
}
void GetUID(u8 *uid)
{
    u8 data[11];
    u16 i;
    u8 CheckCode=0; //����У����
				//     while(1)
				//     {   
			FlagRecFished=0;
			Usart2PutStr(GedUIDMsg,11);
			delay_ms(100); 
//      printf("sended   FlagRecFished=%d\r\n",FlagRecFished);
			if(FlagRecFished)
			{
// printf("FlagRecFished \r\n");
				FlagRecFished=0;
				ReadYulanCard(uid);//��������
				ReadBlueWhiteCard(uid);
				
				
				CleanBuffer(50);//��� ���ڽ��ջ�����ǰ30 ���ֽ�����
				
				
				//00 00 FF 1C E4 D5 4B 01 01 00 04 28 04 E6 C7 AF FC 10 78 80 A0 02 20 90 00 00 00 00 00 E6 C7 AF FC A4 00 
				// 				for(i=start_index+5;i<start_index+32;i++)
				// 				{
				// 						temp+=USART2_RX_BUF[i];
				// 				}
				// 				CheckCode=0x100-temp;
				// 				if(CheckCode==USART2_RX_BUF[start_index+33])
				// 				{
				// 						printf("CheckCode ok ok ok  ok ok ok ok ok ok  \r\n");
				// 					  uid[0]=USART2_RX_BUF[start_index+13];
				// 						uid[1]=USART2_RX_BUF[start_index+14];
				// 						uid[2]=USART2_RX_BUF[start_index+15];
				// 						uid[3]=USART2_RX_BUF[start_index+16];  
				// 						printf("UID:");
				// 						printf("%X ",uid[0]);
				// 						printf("%X ",uid[1]);
				// 						printf("%X ",uid[2]);
				// 						printf("%X \r\n",uid[3]);
				// 				}
				// 				else
				// 				{
				// 							printf("CheckCode error \r\n");
				// 				}
					
					
				}


	
}


void CleanBuffer(u16 num)//���� ǰ ���ٸ��ֽڵ�����
{
    u16 i=0;
    for(i=0;i<num;i++)
      USART2_RX_BUF[i]=0x00;
		USART2_RX_STA = 0;

}




