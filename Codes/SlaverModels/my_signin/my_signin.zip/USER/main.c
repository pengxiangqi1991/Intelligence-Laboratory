#include "led.h"
#include "delay.h"
#include "sys.h"
#include "usart.h"
#include "key.h"
#include "usart2.h"	
#include "nfc.h"
#include "timer.h"
#include "beep.h"
#include <string.h>
#define ADMIN_NUM 11 
//11



u8 UidArray[10]; 
u8 LastUid[10]={0,0,0,0,0};

void AdminOpenDoor(u8 *uid);
void CleanBuf(u8 buf[],u16 len);
u8 IfRepeat(u16 set_second);
u8 SignInConfirme(void)
{
	if(USART_RX_STA>40)
	{
		//{"syn":1001,"id":1,"packetType":1000,"ack":1}
 		if(strstr(USART_RX_BUF,"\"packetType\":1000"))
		{
			if(strstr(USART_RX_BUF,"\"cmd\":1"))
			{
					if(strstr(USART_RX_BUF,"\"id\":1"))
						if(strstr(USART_RX_BUF,"\"syn\":1001"))
						{
							CleanBuf(USART_RX_BUF,USART_RX_STA);
							USART_RX_STA=0;
							return 1;
						}
			}

		}
		CleanBuf(USART_RX_BUF,USART_RX_STA);
		USART_RX_STA=0;

	}
return 0;
}
 int main(void)
 { 
  NVIC_Configuration();	 
	delay_init();	    	 //��ʱ������ʼ��	  
	uart_init(115200);	 	//���ڳ�ʼ��Ϊ9600			 
	LED_Init();         	//LED��ʼ��	 
	KEY_Init();				//������ʼ��	  													    
 	USART2_Init(115200);	//��ʼ������2 //
	TIM3_Int_Init(7200,10000);//����1S��ʱ���ʱ
 	 BEEP_Init();
//	printf("Hello \r\n");
	 KEY_Init();
 
 	nfc_WakeUp();	

	BEEP=0;
	delay_ms(50);

	BEEP=1;
	delay_ms(50);
	BEEP=0;
	delay_ms(50);
	BEEP=1;
	delay_ms(50);
	BEEP=0;
	delay_ms(50);
	BEEP=1;
	delay_ms(50);


	while(1)
	{

		delay_ms(100);
		GetUID(UidArray);
		if(!IfRepeat(5))
		{
			printf("{\"syn\":1000,\"id\":1,\"packetType\":1000,\"userID\":\"%X%X%X%X\"}\n",UidArray[1],UidArray[2],UidArray[3],UidArray[4]);
			BEEP=0;
			delay_ms(50);
			BEEP=1;
		}
		if(1==SignInConfirme())
		{
// 			BEEP=0;
// 			delay_ms(50);
// 			BEEP=1;
			delay_ms(50);
			BEEP=0;
			delay_ms(50);
			BEEP=1;
			delay_ms(50);
			BEEP=0;
			delay_ms(50);
			BEEP=1;
			delay_ms(50);		
		}
		CleanBuf(UidArray,8);
		
	}
}

u8 IfRepeat(u16 set_second)
{
//	printf("%d\r\n",SecondCount);
	if(UidArray[1]||UidArray[2]||UidArray[3]||UidArray[4])
	{
		
		if((LastUid[1]==UidArray[1])&&(LastUid[2]==UidArray[2])&&(LastUid[3]==UidArray[3])&&(LastUid[4]==UidArray[4]))
		{
			if(SecondCount>set_second)
			{
				SecondCount=0;
				return 0;
			}
			else 
				return 1;
		}
		else
		{
			LastUid[1]=UidArray[1];
			LastUid[2]=UidArray[2];
			LastUid[3]=UidArray[3];
			LastUid[4]=UidArray[4];
			SecondCount=0;
			return 0;
		}
	}
	else
		return 1;
		
}


void CleanBuf(u8 *buf,u16 len)
{
	u16 i;
	for(i=0;i<len;i++)
	{
			buf[i]=0;
	}
}


